﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetCoreAutomation.TestData
{
   public class TestConfig
    {
        public static String externalUrl = "https://flipkart.com";
        public static String internalUrl = "https://dev-flipkart.com";
        public static String validPassword = "Test@123";
        public static String invalidPassword = "Test@12345";
    }
}
